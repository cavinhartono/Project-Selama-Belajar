package Programming.ObjectOrientedProgramming.SoalUTS.Geometri;

public abstract class BangunDatar {
  abstract double hitungLuas();
}
